# Summary

- [Rules ForeignCc](index.md)
    - [Rules](rules.md)
        - [cmake](cmake.md)
        - [configure_make](configure_make.md)
        - [make](make.md)
        - [ninja](ninja.md)
- [Full API](flatten.md)
