# Rules ForeignCc

Rules for building C/C++ projects using foreign build systems (non Bazel) inside Bazel projects.

## Versions

- [main](main/index.md)
- [0.8.0](0.8.0/index.md)
- [0.7.1](0.7.1/index.md)
- [0.7.0](0.7.0/index.md)
- [0.6.0](0.6.0/index.md)
- [0.5.1](0.5.1/index.md)
- [0.5.0](0.5.0/index.md)
- [0.4.0](0.4.0/index.md)
- [0.3.0](0.3.0/index.md)
- [0.2.0](0.2.0/index.md)
- [0.1.0](0.1.0/index.md)
