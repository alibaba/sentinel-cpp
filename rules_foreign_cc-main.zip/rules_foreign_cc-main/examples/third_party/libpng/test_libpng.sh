#!/usr/bin/env bash

set -e

$1 $2 $3
