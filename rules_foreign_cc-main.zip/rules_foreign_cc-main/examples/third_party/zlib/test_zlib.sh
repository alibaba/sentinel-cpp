#!/usr/bin/env bash

$(rlocation rules_foreign_cc/examples/cmake/zlib_usage_example)