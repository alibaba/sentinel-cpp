# Rules Foreign CC Third Party Examples

This package contains examples of `rules_foreign_cc` building common/popular third-party source code.

For more details on how the examples here should be structured. Please see the documentation in [@rules_foreign_cc_examples//:README.md](../README.md#third-party).
