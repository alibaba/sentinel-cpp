#ifndef LIB_H_
#define LIB_H_

void hello_world();

#endif
