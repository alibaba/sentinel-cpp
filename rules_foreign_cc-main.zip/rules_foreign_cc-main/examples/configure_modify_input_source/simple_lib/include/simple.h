#ifndef SIMPLE_H_
#define SIMPLE_H_ (1)

int simpleFun(void);

#endif // SIMPLE_H_