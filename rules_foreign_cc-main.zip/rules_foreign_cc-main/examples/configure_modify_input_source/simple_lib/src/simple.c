#include "simple.h"

int simpleFun(void) {
  return 42;
}