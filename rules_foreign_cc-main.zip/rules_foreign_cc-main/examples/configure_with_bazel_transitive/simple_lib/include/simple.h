#ifndef SIMPLE_H_
#define SIMPLE_H_ (1)

void simpleFun(void);

#endif // SIMPLE_H_