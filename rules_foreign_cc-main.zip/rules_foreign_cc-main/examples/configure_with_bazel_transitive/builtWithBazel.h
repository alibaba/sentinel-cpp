#ifndef BUILT_WITH_BAZEL_H_
#define BUILT_WITH_BAZEL_H_ (1)

char* bazelSays(void);

#endif // BUILT_WITH_BAZEL_H_