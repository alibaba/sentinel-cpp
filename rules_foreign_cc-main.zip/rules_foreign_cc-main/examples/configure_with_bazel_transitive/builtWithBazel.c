#include "builtWithBazel.h"

char* bazelSays(void) {
  return "It's me, Bazel!";
}