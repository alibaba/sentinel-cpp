#include "hello.h"

int main(int argc, char* argv[])
{
  hello_func();
  return 0;
}