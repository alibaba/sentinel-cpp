#!/usr/bin/env bash

$(rlocation rules_foreign_cc/examples/cmake_hello_world_lib/$1)