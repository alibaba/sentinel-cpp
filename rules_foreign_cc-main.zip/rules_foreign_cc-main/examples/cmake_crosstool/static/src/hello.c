#include "hello.h"

void hello_func(void) {
	printf("Hello World!\n");

	return;
}