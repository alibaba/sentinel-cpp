#ifndef HELLO_H_
#define HELLO_H_ (1)

#include <stdio.h>

void hello_func(void);

#endif