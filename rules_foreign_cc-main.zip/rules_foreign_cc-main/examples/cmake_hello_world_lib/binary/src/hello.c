#include "hello.h"

void hello_func(char* name) {
	printf("Hello, %s!", name);
}