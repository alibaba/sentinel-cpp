#ifndef LIBB_H_
#define LIBB_H_ (1)

#include <stdio.h>
#include <string>
#include "liba.h"

std::string hello_libb(void);

#endif