#include "libb.h"

std::string hello_libb(void) {
  return hello_liba() + " Hello from LIBB!";
}