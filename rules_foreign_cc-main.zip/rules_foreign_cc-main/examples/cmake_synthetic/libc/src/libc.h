#ifndef LIBC_H_
#define LIBC_H_ (1)

#include <stdio.h>
#include <string>
#include "liba.h"
#include "libb.h"

std::string hello_libc(void);

#endif