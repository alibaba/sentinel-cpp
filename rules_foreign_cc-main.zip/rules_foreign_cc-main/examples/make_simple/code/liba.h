#ifndef LIBA_H_
#define LIBA_H_ (1)

#include <stdio.h>
#include <string>

std::string hello_liba(void);
double hello_math(double);

#endif
