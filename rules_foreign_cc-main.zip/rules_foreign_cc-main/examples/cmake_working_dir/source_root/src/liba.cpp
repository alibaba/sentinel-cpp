#include "liba.h"

std::string hello_liba(void) {
  return "Hello from LIBA!";
}
