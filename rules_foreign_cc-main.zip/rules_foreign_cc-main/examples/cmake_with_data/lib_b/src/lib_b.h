#ifndef LIB_B_H_
#define LIB_B_H_

#include <string>

std::string hello_world();

#endif
