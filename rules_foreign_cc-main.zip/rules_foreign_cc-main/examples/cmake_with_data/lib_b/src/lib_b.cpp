#include "lib_b.h"

std::string hello_data(std::string path)
{
    return std::string("Hello world!");
}
