#ifndef LIB_H_
#define LIB_H_

#include <string>

std::string hello_data(std::string path);

#endif
